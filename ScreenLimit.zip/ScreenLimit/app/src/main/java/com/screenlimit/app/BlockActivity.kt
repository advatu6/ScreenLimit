package com.screenlimit.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** The "time's up" screen shown when a limited app is opened after the daily time ran out. */
class BlockActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#1E2A38"))
            setPadding((32 * dp).toInt(), 0, (32 * dp).toInt(), 0)
        }

        root.addView(TextView(this).apply {
            text = "⏳"
            textSize = 64f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "נגמר הזמן להיום"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, (16 * dp).toInt(), 0, (8 * dp).toInt())
        })
        root.addView(TextView(this).apply {
            text = "אינסטגרם, יוטיוב וטיקטוק ייפתחו שוב מחר.\nוואטסאפ, שיחות והודעות פתוחים כרגיל."
            textSize = 17f
            setTextColor(Color.parseColor("#C9D3DE"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (32 * dp).toInt())
        })
        root.addView(Button(this).apply {
            text = "סגור"
            setOnClickListener { goHome() }
        })

        setContentView(root)
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }
}
