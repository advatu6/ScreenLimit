package com.screenlimit.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.time.LocalDate

/**
 * Watches which app is in the foreground. While a limited app is open, it counts time.
 * When today's time runs out, it sends you to the home screen and shows the "time's up" screen.
 */
class BlockerService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var currentPkg: String? = null
    private var lastTick = 0L
    private var lastBlock = 0L

    private var warnDay = ""
    private var warned5 = false
    private var warned1 = false

    private val ignored by lazy { setOf(packageName, "com.android.systemui") }

    private val ticker = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastTick = SystemClock.elapsedRealtime()
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignored) return
        currentPkg = pkg
        if (pkg in UsageStore.LIMITED_APPS && UsageStore.isOverLimit(this)) {
            block()
        }
    }

    private fun foregroundPackage(): String? {
        val fromWindow = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (e: Exception) {
            null
        }
        return if (fromWindow != null && fromWindow !in ignored) fromWindow else currentPkg
    }

    private fun onTick() {
        val now = SystemClock.elapsedRealtime()
        val elapsed = (now - lastTick).coerceIn(0L, 2000L)
        lastTick = now

        val power = getSystemService(PowerManager::class.java)
        if (power != null && !power.isInteractive) return  // screen is off

        val pkg = foregroundPackage() ?: return
        if (pkg !in UsageStore.LIMITED_APPS) return

        UsageStore.addUsed(this, elapsed)
        val remaining = UsageStore.remainingMs(this)

        val today = LocalDate.now().toString()
        if (today != warnDay) {
            warnDay = today; warned5 = false; warned1 = false
        }
        if (remaining in 1..5 * 60_000L && !warned5) {
            warned5 = true
            Toast.makeText(this, "נשארו 5 דקות להיום", Toast.LENGTH_LONG).show()
        }
        if (remaining in 1..60_000L && !warned1) {
            warned1 = true
            Toast.makeText(this, "נשארה דקה אחת", Toast.LENGTH_LONG).show()
        }
        if (remaining <= 0) block()
    }

    private fun block() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 1500) return
        lastBlock = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        val intent = Intent(this, BlockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "נגמר הזמן להיום", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}
