package com.screenlimit.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var enableButton: Button
    private lateinit var usageText: TextView
    private lateinit var pendingText: TextView
    private lateinit var limitInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            gravity = Gravity.START
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setTextColor(Color.parseColor("#1E2A38"))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (6 * dp).toInt(), 0, (6 * dp).toInt())
        }

        col.addView(label("מגביל זמן", 28f, true))

        statusText = label("")
        col.addView(statusText)
        enableButton = Button(this).apply {
            text = "הפעל הרשאת נגישות"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        col.addView(enableButton)

        col.addView(label("היום", 20f, true).apply { setPadding(0, pad, 0, 0) })
        usageText = label("", 18f)
        col.addView(usageText)

        col.addView(label("מגבלה יומית (דקות, סה״כ לכל האפליקציות)", 20f, true).apply { setPadding(0, pad, 0, 0) })
        limitInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 20f
        }
        col.addView(limitInput)
        col.addView(Button(this).apply {
            text = "שמור"
            setOnClickListener { saveLimit() }
        })
        pendingText = label("", 14f)
        col.addView(pendingText)
        col.addView(label("הורדת המגבלה נכנסת לתוקף מיד. העלאה שלה נכנסת לתוקף רק מחר, כדי שלא יהיה קל לוותר לעצמך ברגע של חולשה.", 14f).apply {
            setTextColor(Color.GRAY)
        })

        col.addView(label("אפליקציות מוגבלות", 20f, true).apply { setPadding(0, pad, 0, 0) })
        col.addView(label(UsageStore.LIMITED_APPS.values.distinct().joinToString(" · ")))
        col.addView(label("כל השאר, כולל וואטסאפ, שיחות והודעות, תמיד פתוח.", 14f).apply {
            setTextColor(Color.GRAY)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F5F7FA"))
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun refresh() {
        val on = isServiceEnabled()
        statusText.text = if (on) "✅ ההגבלה פעילה" else "⚠️ ההגבלה כבויה. צריך להפעיל הרשאת נגישות."
        enableButton.visibility = if (on) View.GONE else View.VISIBLE

        val limit = UsageStore.limitMinutes(this)
        val usedMin = UsageStore.usedMs(this) / 60_000
        val leftMin = (UsageStore.remainingMs(this).coerceAtLeast(0) + 59_999) / 60_000
        usageText.text = "השתמשת $usedMin דקות מתוך $limit. נשארו $leftMin דקות."
        limitInput.setText(limit.toString())

        val pending = UsageStore.pendingLimit(this)
        pendingText.text = if (pending > 0) "מחר המגבלה תעלה ל-$pending דקות." else ""
    }

    private fun saveLimit() {
        val minutes = limitInput.text.toString().toIntOrNull()
        if (minutes == null || minutes < 0 || minutes > 600) {
            Toast.makeText(this, "הכנס מספר בין 0 ל-600", Toast.LENGTH_SHORT).show()
            return
        }
        val immediate = UsageStore.requestLimit(this, minutes)
        Toast.makeText(
            this,
            if (immediate) "נשמר" else "המגבלה החדשה תיכנס לתוקף מחר",
            Toast.LENGTH_LONG
        ).show()
        refresh()
    }
}
