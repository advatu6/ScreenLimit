package com.screenlimit.app

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

/** Stores today's usage and the daily limit. All time is combined across the limited apps. */
object UsageStore {

    /** Apps that get a daily time limit. Everything else (WhatsApp, Phone, SMS...) is never touched. */
    val LIMITED_APPS = mapOf(
        "com.instagram.android" to "אינסטגרם",
        "com.google.android.youtube" to "יוטיוב",
        "com.zhiliaoapp.musically" to "טיקטוק",
        "com.ss.android.ugc.trill" to "טיקטוק",
    )

    const val DEFAULT_LIMIT_MIN = 30

    private const val PREFS = "screen_limit"
    private const val K_DAY = "day"
    private const val K_USED = "used_ms"
    private const val K_LIMIT = "limit_min"
    private const val K_PENDING = "pending_limit_min"
    private const val K_PENDING_FROM = "pending_from"

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String = LocalDate.now().toString()

    fun usedMs(c: Context): Long {
        val p = prefs(c)
        return if (p.getString(K_DAY, "") == today()) p.getLong(K_USED, 0L) else 0L
    }

    fun addUsed(c: Context, ms: Long) {
        if (ms <= 0) return
        val p = prefs(c)
        val t = today()
        val current = if (p.getString(K_DAY, "") == t) p.getLong(K_USED, 0L) else 0L
        p.edit().putString(K_DAY, t).putLong(K_USED, current + ms).apply()
    }

    /** The limit in effect today. A raised limit that was waiting for tomorrow is applied here. */
    fun limitMinutes(c: Context): Int {
        val p = prefs(c)
        val pending = p.getInt(K_PENDING, -1)
        val from = p.getString(K_PENDING_FROM, null)
        if (pending > 0 && from != null && from <= today()) {
            p.edit().putInt(K_LIMIT, pending).remove(K_PENDING).remove(K_PENDING_FROM).apply()
        }
        return p.getInt(K_LIMIT, DEFAULT_LIMIT_MIN)
    }

    fun pendingLimit(c: Context): Int = prefs(c).getInt(K_PENDING, -1)

    /**
     * Lowering the limit takes effect right away.
     * Raising it only takes effect tomorrow, so you can't "cheat" in a weak moment.
     * Returns true if applied immediately.
     */
    fun requestLimit(c: Context, minutes: Int): Boolean {
        val current = limitMinutes(c)
        val p = prefs(c)
        return if (minutes <= current) {
            p.edit().putInt(K_LIMIT, minutes).remove(K_PENDING).remove(K_PENDING_FROM).apply()
            true
        } else {
            p.edit()
                .putInt(K_PENDING, minutes)
                .putString(K_PENDING_FROM, LocalDate.now().plusDays(1).toString())
                .apply()
            false
        }
    }

    fun remainingMs(c: Context): Long = limitMinutes(c) * 60_000L - usedMs(c)

    fun isOverLimit(c: Context): Boolean = remainingMs(c) <= 0
}
